=== toowl – Browser Tools ===
Contributors: salingjaga
Donate link: https://trakteer.id/chalidade/tip
Tags: qr code, prayer times, password generator, calculator, tools
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Browser-only tools as blocks and shortcodes: files never leave the visitor's device.

== Description ==

toowl puts ready-made tools on your pages: add a block, or paste a shortcode. Every tool runs in your visitor's browser. Files they open in a tool are never uploaded, not to your server and not to anyone else, so your hosting does no work and nothing private leaves their device.

Tools in this plugin:

* **QR Code Generator**: Make QR codes for links, text, Wi-Fi, WhatsApp, contacts or email — with a logo and colors.
* **Prayer Times**: Daily and monthly prayer times for your city or location, computed on your device with the Kemenag method, no internet needed, printable.
* **Hijri ⇄ Gregorian Converter**: Convert Gregorian dates to Hijri and back, plus a year of Islamic holidays, with a note on Kemenag’s moon-sighting differences.
* **Qibla Direction**: Work out the Qibla bearing from your location and aim your phone with a live compass, with a calibration warning.
* **Word Counter**: Count words, characters, sentences and paragraphs, estimate reading and speaking time, and check X, Instagram and meta description limits.
* **Password Generator**: Generate random passwords or Indonesian/English passphrases, and check how strong a password is with an estimated time to guess.
* **Unit Converter**: Convert length, weight (ons, quintal), area (hectare, are, tumbak), volume, temperature, speed and data sizes.
* **Percentage & Discount Calculator**: Work out X% of Y, what percent, percent increase/decrease, and stacked discounts (50% + 20% = 60%) with every step shown.
* **Number to Words**: Turn a number into Indonesian or English words ("satu juta dua ratus ribu rupiah"), with letter-case options for receipts and cheques.
* **Color Picker**: Pick colors from an image or the screen, convert to HEX/RGB/HSL/OKLCH, check contrast and build shades.

**How to add a tool**

* Block editor: open the block inserter, search "toowl", pick the tool.
* Anywhere shortcodes work: `[toowl tool="qr-generator"]`. Options: `theme="auto|light|dark"`, `lang="en|id"` (default: your site language).

Each tool is a web component in a Shadow DOM, so your theme's CSS can't break it. Its JavaScript and WebAssembly are served from this plugin's own folder: no CDN, no third-party requests.

**toowl Pro**

This plugin has 10 free tools and nothing in it is locked. toowl Pro is a separate plugin with 72 tools: PDF (compress, merge, sign, PDF to Word), Office to PDF, image (remove background, compress, passport photo), video and audio, music, business and Islamic tools. A license opens one tool, a theme pack or all of them, from $19: https://toowl.my.id/wordpress/

**Source code**

The JavaScript in `assets/dist/` is built from https://github.com/chalidade/tools (the `src/tools/` folder and `packages/`), the same code as https://toowl.my.id/. Build it with `node packages/_wordpress/build.mjs`.

== External services ==

This plugin connects to no external service. The tools run in the visitor's browser from files in this plugin's folder.

== Frequently Asked Questions ==

= Are files uploaded to my server? =

No. The tools read files with the browser's own APIs and write the result back as a download.

= Is there a "powered by" link? =

Only if you turn it on in Settings → toowl. It is off by default.

== Screenshots ==

1. A QR code generator block on a page: links, text, Wi-Fi, WhatsApp, contacts; PNG or SVG download.
2. Prayer times for any city or the visitor's location, computed on the device.
3. Password generator in dark mode (each block can follow the visitor's theme or be set light or dark).

== Changelog ==

= 1.0.0 =
* First release: 10 tools as blocks and shortcodes.
